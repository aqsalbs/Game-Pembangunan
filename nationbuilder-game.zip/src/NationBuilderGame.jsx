import React, { useState } from 'react';

export default function NationBuilderGame() {
  const [log, setLog] = useState([]);

  const addEvent = (event) => {
    setLog(prev => [...prev, event]);
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">NationBuilder Game</h1>
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded"
        onClick={() => addEvent('Peristiwa baru terjadi')}
      >
        Tambah Peristiwa
      </button>
      <div className="bg-white p-4 rounded shadow mt-4">
        <h4 className="font-semibold">Log Peristiwa</h4>
        <ul>
          {log.map((item, idx) => (
            <li key={idx}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}